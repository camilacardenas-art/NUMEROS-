#include <Keypad.h>
#include <WiFi.h>
#include <HTTPClient.h>

const byte ROWS = 4; 
const byte COLS = 4; 

char keys[ROWS][COLS] = {
  {'1','2','3','A'},
  {'4','5','6','B'},
  {'7','8','9','C'},
  {'*','0','#','D'}
};

byte rowPins[ROWS] = {13, 12, 14, 27}; 
byte colPins[COLS] = {26, 25, 33, 32}; 

Keypad keypad = Keypad(makeKeymap(keys), rowPins, colPins, ROWS, COLS);

void setup() {
  Serial.begin(115200);
  
  // Conectar al WiFi virtual de Wokwi
  WiFi.begin("Wokwi-GUEST", "");
  while (WiFi.status() != WL_CONNECTED) {
    delay(100);
  }
  Serial.println("WiFi Conectado en Wokwi!");
}

void loop() {
  char key = keypad.getKey();
  
  if (key) {
    Serial.println(key);
    
    // Enviar la tecla al puente local por HTTP
    if (WiFi.status() == WL_CONNECTED) {
      HTTPClient http;
      String url = "http://host.wokwi.internal:8080/?key=" + String(key);
      http.begin(url);
      http.GET();
      http.end();
    }
  }
  delay(10);
}